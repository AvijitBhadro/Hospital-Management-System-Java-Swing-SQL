package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateEmployeeInfo extends JFrame implements ActionListener {

    JTextField tfSearch, tfName, tfSpecialization, tfContact;
    JButton searchButton, updateButton, backButton;
    JLabel lblID;
    int currentID;

    UpdateEmployeeInfo() {
        setTitle("Update Doctor Information");

        setBounds(530, 320, 600, 400);
        getContentPane().setBackground(new Color(109,164,170));
        setLayout(null);

        JLabel lblSearch = new JLabel("Enter Doctor ID:");
        lblSearch.setBounds(50, 50, 150, 30);
        lblSearch.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblSearch.setForeground(Color.BLACK);
        add(lblSearch);

        tfSearch = new JTextField();
        tfSearch.setBounds(200, 50, 150, 25);
        tfSearch.setBackground(new Color(255,179,0));
        add(tfSearch);

        searchButton = new JButton("Search");
        searchButton.setBounds(370, 50, 120, 30);
        searchButton.setFont(new Font("serif",Font.BOLD,16));
        searchButton.setBackground(Color.BLACK);
        searchButton.setForeground(Color.white);
        searchButton.addActionListener(this);
        add(searchButton);

        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(50, 100, 150, 30);
        lblName.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblName.setForeground(Color.BLACK);
        add(lblName);

        tfName = new JTextField();
        tfName.setBounds(200, 100, 150, 25);
        tfName.setBackground(new Color(255,179,0));
        add(tfName);

        JLabel lblSpecialization = new JLabel("Department:");
        lblSpecialization.setBounds(50, 150, 150, 30);
        lblSpecialization.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblSpecialization.setForeground(Color.BLACK);
        add(lblSpecialization);

        tfSpecialization = new JTextField();
        tfSpecialization.setBounds(200, 150, 150, 25);
        tfSpecialization.setBackground(new Color(255,179,0));
        add(tfSpecialization);

        JLabel lblContact = new JLabel("Email:");
        lblContact.setBounds(50, 200, 150, 30);
        lblContact.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblContact.setForeground(Color.BLACK);
        add(lblContact);

        tfContact = new JTextField();
        tfContact.setBounds(200, 200, 150, 25);
        tfContact.setBackground(new Color(255,179,0));
        add(tfContact);

        updateButton = new JButton("Update");
        updateButton.setBounds(100, 250, 120, 30);
        updateButton.setFont(new Font("serif",Font.BOLD,16));
        updateButton.setBackground(Color.BLACK);
        updateButton.setForeground(Color.white);
        updateButton.addActionListener(this);
        add(updateButton);

        backButton = new JButton("Back");
        backButton.setBounds(250, 250, 120, 30);
        backButton.setFont(new Font("serif",Font.BOLD,16));
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.white);
        backButton.addActionListener(this);
        add(backButton);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == searchButton) {
            try {
                String query = "SELECT * FROM EMP_INFO WHERE Employee_ID = '" + tfSearch.getText() + "'";
                con c = new con();
                ResultSet rs = c.statement.executeQuery(query);
                if (rs.next()) {
                    currentID = rs.getInt("Employee_ID");
                    tfName.setText(rs.getString("Name"));
                    tfSpecialization.setText(rs.getString("Department"));
                    tfContact.setText(rs.getString("Email"));
                } else {
                    JOptionPane.showMessageDialog(null, "Doctor not found");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == updateButton) {
            try {
                String query = "UPDATE EMP_INFO SET Name = ?, Department = ?, Email = ? WHERE Employee_ID = ?";
                con c = new con();
                PreparedStatement ps = c.connection.prepareStatement(query);
                ps.setString(1, tfName.getText());
                ps.setString(2, tfSpecialization.getText());
                ps.setString(3, tfContact.getText());
                ps.setInt(4, currentID);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, "Doctor info updated successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == backButton) {
            new Admin();
            dispose();
        }
    }

    public static void main(String[] args) {
        new UpdateEmployeeInfo();
    }
}
