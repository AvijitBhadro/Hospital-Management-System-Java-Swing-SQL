package hospital.management.system;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;

public class con {
    Connection connection;

    Statement statement;


    public con() {
    try{

        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system","root","sqllearner18");
        statement = connection.createStatement();
    }
    catch(Exception e) {
        e.printStackTrace();
    }
    }

    public Statement getStatement() {
        return statement;
    }

    public void setStatement(Statement statement) {
        this.statement = statement;
    }
}
