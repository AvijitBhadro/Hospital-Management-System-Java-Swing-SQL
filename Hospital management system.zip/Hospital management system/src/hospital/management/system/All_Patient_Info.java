package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class All_Patient_Info extends JFrame {

    All_Patient_Info() {
        setTitle("Patient Details");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600); // Adjusted frame size
        setLocationRelativeTo(null);
        setLayout(null);

        // Create panel
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 980, 520); // Adjusted panel bounds to match frame size
        panel.setBackground(new Color(109, 164, 170));
        panel.setLayout(null);
        add(panel);

        // Create table
        JTable table = new JTable();
        table.setFont(new Font("Tahoma", Font.BOLD, 14)); // Adjusted font size
        table.setBackground(new Color(200, 220, 230));
        table.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 14)); // Adjusted font size for header

        // Create scroll pane and add table to it
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 40, 940, 400); // Adjusted bounds to fit within the new frame size
        panel.add(scrollPane);

        // Load data into table
        try {
            con c = new con();
            String q = "SELECT * FROM patient_info";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

            // Adjust column widths
            int[] columnWidths = {80, 120, 120, 200, 120, 120, 120, 180, 120}; // Adjusted column widths
            for (int i = 0; i < columnWidths.length; i++) {
                table.getColumnModel().getColumn(i).setPreferredWidth(columnWidths[i]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Back button
        JButton button = new JButton("BACK");
        button.setBounds(440, 480, 120, 40);

        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(button);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Admin();
                setVisible(false);
            }
        });

        // Show frame
        setVisible(true);
    }

    public static void main(String[] args) {
        new All_Patient_Info();
    }
}
