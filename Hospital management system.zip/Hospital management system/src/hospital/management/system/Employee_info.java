package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Employee_info extends JFrame {
    Employee_info() {
        setTitle("Employee Info");
        setBounds(450, 230, 1000, 700);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setBounds(5, 5, 970, 650);
        mainPanel.setBackground(new Color(109, 164, 170));
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(mainPanel);

        JPanel panelLogo = new JPanel();
        panelLogo.setBackground(new Color(109, 164, 170));
        panelLogo.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        mainPanel.add(panelLogo, BorderLayout.NORTH);

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icon/dr.png"));
        Image img = icon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(img);
        JLabel logoLabel = new JLabel(scaledIcon);
        panelLogo.add(logoLabel);

        JLabel titleLabel = new JLabel("Doctor Information");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        panelLogo.add(titleLabel);

        JPanel panelTable = new JPanel();
        panelTable.setBackground(new Color(109, 164, 170));
        panelTable.setLayout(new BorderLayout());
        mainPanel.add(panelTable, BorderLayout.CENTER);

        JTable table = new JTable();
        table.setFont(new Font("Tahoma", Font.BOLD, 12));
        table.setRowHeight(25);
        table.setBackground(new Color(200, 220, 230));
        table.setFillsViewportHeight(true);

        // Custom header renderer to make the text bold
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(new Font("Tahoma", Font.BOLD, 14)); // Set the header font to bold
        tableHeader.setBackground(new Color(109, 164, 170));
        tableHeader.setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        panelTable.add(scrollPane, BorderLayout.CENTER);

        try {
            con c = new con();
            String q = "select * from EMP_INFO";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(109, 164, 170));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        JButton backButton = new JButton("BACK");
        backButton.setPreferredSize(new Dimension(120, 30));
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new Admin();
                setVisible(false);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new Employee_info();
    }
}
