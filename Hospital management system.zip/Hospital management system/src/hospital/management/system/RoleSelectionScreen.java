package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RoleSelectionScreen extends JFrame implements ActionListener {

    JButton adminButton, userButton;

    RoleSelectionScreen() {
        setTitle("Hospital Management System");


        adminButton = new JButton("Admin");
        adminButton.setBounds(150, 100, 150, 50);
        adminButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        adminButton.setBackground(new Color(255, 204, 102));
        adminButton.setForeground(Color.BLACK);
        adminButton.addActionListener(this);
        add(adminButton);


        userButton = new JButton("User");
        userButton.setBounds(350, 100, 150, 50);
        userButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        userButton.setBackground(new Color(255, 204, 102));
        userButton.setForeground(Color.BLACK);
        userButton.addActionListener(this);
        add(userButton);


        getContentPane().setBackground(new Color(109, 164, 170));
        setSize(650, 300);
        setLocation(580, 320);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminButton) {
            new Login();
            setVisible(false);
        } else if (e.getSource() == userButton) {
            new UserLogin();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new RoleSelectionScreen();
    }
}
