package hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AllAppointments extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private con dbConnection;

    public AllAppointments() {
        setTitle("All Appointments");
        setSize(800, 600);
        getContentPane().setBackground(new Color(109, 164, 170));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        dbConnection = new con();

        tableModel = new DefaultTableModel(new Object[]{"Patient ID", "Patient Name", "Doctor Name", "Appointment Date", "Reason"}, 0);
        table = new JTable(tableModel);
        table.setFont(new Font("Tahoma", Font.BOLD, 14));
        table.setBackground(new Color(109, 164, 170)); // Set background color for the JTable
        table.setRowHeight(25);

        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer(new TableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = new JLabel(value.toString());
                label.setFont(new Font("Tahoma", Font.BOLD, 14));
                label.setHorizontalAlignment(SwingConstants.CENTER);
                return label;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadAppointmentsData();

        JButton backButton = new JButton("BACK");
        backButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        backButton.setBounds(340, 500, 120, 40); // Positioning the button below the table

        // Adding action listener to handle back button click
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);

            }
        });

        // Adding the button to the content pane
        add(backButton, BorderLayout.SOUTH);
setTitle("Appointments");
        setUndecorated(true);
        setVisible(true);
    }

    private void loadAppointmentsData() {
        try {
            String query = "SELECT p.patient_id, p.Name AS patient_name, d.Name AS doctor_name, a.appointment_date, a.reason " +
                    "FROM patient_info p " +
                    "JOIN Appointments a ON p.patient_id = a.patient_id " +
                    "JOIN EMP_INFO d ON a.doctor_id = d.Employee_ID " +
                    "ORDER BY a.appointment_date DESC";
            ResultSet resultSet = dbConnection.statement.executeQuery(query);

            while (resultSet.next()) {
                String patientId = resultSet.getString("patient_id");
                String patientName = resultSet.getString("patient_name");
                String doctorName = resultSet.getString("doctor_name");
                Date appointmentDate = resultSet.getDate("appointment_date");
                String reason = resultSet.getString("reason");

                tableModel.addRow(new Object[]{patientId, patientName, doctorName, appointmentDate, reason});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading appointment data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new AllAppointments();
    }
}
