package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WelcomeScreen extends JFrame implements ActionListener {

    JButton proceedButton;

    WelcomeScreen() {

        setTitle("Hospital Management System");

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/GH.jpg"));
        Image i1 = imageIcon.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(i1);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(180, 0, 180, 180);
        add(label);

        JLabel welcomeLabel = new JLabel("Welcome to Green Hospital");
        welcomeLabel.setBounds(105, 210, 500, 30);
        welcomeLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
        welcomeLabel.setForeground(Color.WHITE);
        add(welcomeLabel);

        proceedButton = new JButton("Proceed to Login");
        proceedButton.setBounds(180, 270, 180, 40);
        proceedButton.setFont(new Font("Tahoma", Font.BOLD, 15));
        proceedButton.setBackground(new Color(0, 128, 128));
        proceedButton.setForeground(Color.WHITE);
        proceedButton.setFocusPainted(false);
        proceedButton.addActionListener(this);
        add(proceedButton);

        // Adding hover effect to the proceed button
        proceedButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                proceedButton.setBackground(new Color(0, 100, 100));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                proceedButton.setBackground(new Color(0, 128, 128));
            }
        });

        getContentPane().setBackground(new Color(109, 164, 170));
        setSize(550, 400);  // Decreased the frame size
        setLocationRelativeTo(null);  // Center the frame on the screen
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == proceedButton) {
            new RoleSelectionScreen();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new WelcomeScreen();
    }
}
