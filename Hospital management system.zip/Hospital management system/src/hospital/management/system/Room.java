package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Room extends JFrame {

    Room() {
        setTitle("Room Information");
        setBounds(250, 100, 1000, 700); // Increased frame size
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout(10, 10));


        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(90, 156, 163));
        mainPanel.setLayout(new BorderLayout(10, 10));
        add(mainPanel);

        JPanel panelLogo = new JPanel();
        panelLogo.setBackground(new Color(90, 156, 163));
        panelLogo.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        mainPanel.add(panelLogo, BorderLayout.NORTH);


        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/roomm.png"));
        Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(image);
        JLabel logoLabel = new JLabel(scaledIcon);
        panelLogo.add(logoLabel);


        JLabel titleLabel = new JLabel("Room Information");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 28)); // Increased font size
        titleLabel.setForeground(Color.WHITE);
        panelLogo.add(titleLabel);


        JPanel panelTable = new JPanel();
        panelTable.setBackground(new Color(90, 156, 163));
        panelTable.setLayout(new BorderLayout());
        mainPanel.add(panelTable, BorderLayout.CENTER);

        JTable table = new JTable();
        table.setFont(new Font("Tahoma", Font.BOLD, 16)); // Increased font size
        table.setRowHeight(30); // Increased row height
        table.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(table);
        panelTable.add(scrollPane, BorderLayout.CENTER);

        try {
            con c = new con();
            String q = "select room_no,Price,Room_Type from room";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new GridLayout(1, 4, 10, 10));
        headerPanel.setBackground(new Color(90, 156, 163));
        panelTable.add(headerPanel, BorderLayout.NORTH);

        // Panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(90, 156, 163));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        JButton backButton = new JButton("BACK");
        backButton.setPreferredSize(new Dimension(120, 40)); // Increased button size
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Tahoma", Font.BOLD, 18)); // Increased font size
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Admin();
                setVisible(false);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new Room();
    }
}
