package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Signup extends JFrame implements ActionListener {

    JButton create, back;
    JTextField tfname, tfusername, tfpassword;

    Signup() {

        // Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(109, 164, 170));
        mainPanel.setLayout(new BorderLayout(10, 10));
        add(mainPanel);

        // Left Panel for Form
        JPanel formPanel = new JPanel();
        formPanel.setBackground(new Color(109, 164, 170));
        formPanel.setLayout(null);
        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Logo Panel
        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(new Color(109, 164, 170));
        logoPanel.setLayout(new BorderLayout());
        mainPanel.add(logoPanel, BorderLayout.EAST);

        JLabel newaccount = new JLabel("Creating New Account...");
        newaccount.setFont(new Font("Tahoma", Font.BOLD, 20));
        newaccount.setBounds(40, 10, 250, 50);
        newaccount.setForeground(Color.BLACK);
        formPanel.add(newaccount);

        JLabel lblusername = new JLabel("Username");
        lblusername.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblusername.setBounds(40, 80, 100, 30);
        lblusername.setForeground(Color.BLACK);
        formPanel.add(lblusername);

        tfusername = new JTextField();
        tfusername.setBounds(150, 80, 150, 30);
        tfusername.setFont(new Font("Tahoma", Font.PLAIN, 15));
        tfusername.setBackground(new Color(255, 179, 0));
        formPanel.add(tfusername);

        JLabel lblname = new JLabel("Name");
        lblname.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblname.setBounds(40, 130, 100, 30);
        lblname.setForeground(Color.BLACK);
        formPanel.add(lblname);

        tfname = new JTextField();
        tfname.setBounds(150, 130, 150, 30);
        tfname.setFont(new Font("Tahoma", Font.PLAIN, 15));
        tfname.setBackground(new Color(255, 179, 0));
        formPanel.add(tfname);

        JLabel lblpassword = new JLabel("Password");
        lblpassword.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblpassword.setBounds(40, 190, 100, 16);
        lblpassword.setForeground(Color.BLACK);
        formPanel.add(lblpassword);

        tfpassword = new JTextField();
        tfpassword.setBounds(150, 180, 150, 30);
        tfpassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
        tfpassword.setBackground(new Color(255, 179, 0));
        formPanel.add(tfpassword);

        create = new JButton("Create");
        create.setBackground(Color.BLACK);
        create.setForeground(Color.white);
        create.setFont(new Font("serif", Font.BOLD, 15));
        create.setBounds(40, 270, 100, 30);
        create.addActionListener(this);
        formPanel.add(create);

        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.white);
        back.setFont(new Font("TAHOMA", Font.BOLD, 14));
        back.setBounds(200, 270, 100, 30);
        back.addActionListener(this);
        formPanel.add(back);


        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/createaccount.png"));
        Image image = imageIcon.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(image);
        JLabel logoLabel = new JLabel(scaledIcon);
        logoLabel.setBounds(450,3, 250, 300);
        logoPanel.add(logoLabel, BorderLayout.CENTER);



        setSize(650, 400);
        setLocation(550, 270);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == create) {
            String username = tfusername.getText();
            String name = tfname.getText();
            String password = tfpassword.getText();

            String query = "insert into user values('" + username + "','" + name + "','" + password + "')";
            try {
                con c = new con();
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Account Created Successfully");

                new UserLogin();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == back) {
            setVisible(false);
            new UserLogin();
        }
    }

    public static void main(String[] args) {
        new Signup();
    }
}
