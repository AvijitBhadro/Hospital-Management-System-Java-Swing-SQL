package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Admin extends JFrame {

    Admin() {

        JPanel panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBounds(5, 160, 1100, 670);
        panel1.setBackground(new Color(109, 164, 170));
        add(panel1);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(5, 5, 1100, 150);
        panel.setBackground(new Color(0, 105, 20));
        add(panel);


//        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/GH2.jpg"));
//        Image image = i1.getImage().getScaledInstance(150, 170, Image.SCALE_DEFAULT);
//        ImageIcon i2 = new ImageIcon(image);
//        JLabel label = new JLabel(i2);
//        label.setBounds(910, 0, 250, 150);
//        panel.add(label);

        ImageIcon i10 = new ImageIcon(ClassLoader.getSystemResource("icon/Mainlogo.png"));
        Image image9 = i10.getImage().getScaledInstance(300, 100, Image.SCALE_DEFAULT);
        ImageIcon i20 = new ImageIcon(image9);
        JLabel label1 = new JLabel(i20);
        label1.setBounds(90, 35, 900, 100);
        panel.add(label1);

        JButton btn1 = new JButton("Add New Patient");
        btn1.setBounds(30, 140, 200, 30);
        btn1.setBackground(new Color(246, 215, 118));
        panel1.add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new NEW_PATIENT();
            }
        });

        JButton btn2 = new JButton("Room");
        btn2.setBounds(30, 193, 200, 30);
        btn2.setBackground(new Color(246, 215, 118));
        panel1.add(btn2);
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Room();
                setVisible(false);
            }
        });

        JButton btn3 = new JButton("Department");
        btn3.setBounds(30, 245, 200, 30);
        btn3.setBackground(new Color(246, 215, 118));
        panel1.add(btn3);
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Department();
                setVisible(false);
            }
        });

        JButton btn4 = new JButton("All Employee Info");
        btn4.setBounds(270, 140, 200, 30);
        btn4.setBackground(new Color(246, 215, 118));
        panel1.add(btn4);
        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Employee_info();
                setVisible(false);
            }
        });

        JButton btn5 = new JButton("Patient Info");
        btn5.setBounds(270, 193, 200, 30);
        btn5.setBackground(new Color(246, 215, 118));
        panel1.add(btn5);
        btn5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new All_Patient_Info();
                setVisible(false);
            }
        });

        JButton btn6 = new JButton("Patient Discharge");
        btn6.setBounds(270, 245, 200, 30);
        btn6.setBackground(new Color(246, 215, 118));
        panel1.add(btn6);
        btn6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new patient_discharge();
                setVisible(false);
            }
        });

        JButton btn7 = new JButton("Update Patient Details");
        btn7.setBounds(510, 140, 200, 30);
        btn7.setBackground(new Color(246, 215, 118));
        panel1.add(btn7);
        btn7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new update_patient_details();
//                setVisible(false);
            }
        });

        JButton btn8 = new JButton("Update Employee Details");
        btn8.setBounds(510, 193, 200, 30);
        btn8.setBackground(new Color(246, 215, 118));
        panel1.add(btn8);
        btn8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new UpdateEmployeeInfo();

            }
        });

        JButton btn9 = new JButton("Search Room");
        btn9.setBounds(510, 245, 200, 30);
        btn9.setBackground(new Color(246, 215, 118));
        panel1.add(btn9);
        btn9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SearchRoom();

            }
        });

        // New button for "View All Appointments"
        JButton btn11 = new JButton("View All Appointments");
        btn11.setBounds(750, 140, 200, 30);
        btn11.setBackground(new Color(246, 215, 118));
        panel1.add(btn11);
        btn11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AllAppointments();

            }
        });

        // New button for "Add Appointment"
        JButton btn12 = new JButton("Add Appointment");
        btn12.setBounds(750, 193, 200, 30);
        btn12.setBackground(new Color(246, 215, 118));
        panel1.add(btn12);
        btn12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Appointment();
            }
        });

        JButton btn10 = new JButton("Logout");
        btn10.setBounds(750, 245, 200, 30);
        btn10.setBackground(new Color(246, 215, 118));
        panel1.add(btn10);
        btn10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new Login();
            }
        });

        setTitle("Admin");
        setSize(1126, 600);
        setLocation(390, 195);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Admin();
    }
}
