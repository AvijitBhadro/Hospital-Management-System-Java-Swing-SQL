package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ForgetPass extends JFrame implements ActionListener{

    JTextField tfusername, tfname, tfpassword;
    JButton search,rescue,back;

    ForgetPass(){
        setTitle("Hospital Management System");

        setBounds(500, 350, 730, 310);
        getContentPane().setBackground(Color.WHITE);

        setLayout(null);


        JPanel p1 = new JPanel();
        p1.setLayout(null);
        p1.setBounds(4, 5, 700, 300);
        p1.setBackground(new Color(90, 156, 163));
        add(p1);





        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/Passrestore.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(200, 300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(485,3, 250, 300);
        p1.add(image);

        JLabel lblusername = new JLabel("Username");
        lblusername.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblusername.setBounds(40, 20, 100, 25);
        lblusername.setForeground(Color.BLACK);
        p1.add(lblusername);

        tfusername = new JTextField();
        tfusername.setBounds(170, 20, 150, 25);
        tfusername.setBackground(new Color(255,179,0));
        p1.add(tfusername);

        search = new JButton("Search");
        search.setBackground(Color.BLACK);
        search.setForeground(Color.white);
        search.setBounds(350, 20, 120, 35);

        search.addActionListener(this);
        p1.add(search);

        JLabel lblname = new JLabel("Name");
        lblname.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblname.setBounds(40, 60, 120, 30);
        lblname.setForeground(Color.BLACK);
        p1.add(lblname);

        tfname = new JTextField();
        tfname.setBounds(170, 60, 150, 25);
        tfname.setBackground(new Color(255,179,0));
        p1.add(tfname);

        rescue = new JButton("Rescue");
        rescue.setBackground(Color.BLACK);
        rescue.setForeground(Color.white);
        rescue.setBounds(150, 110, 130, 35);
        rescue.addActionListener(this);
        p1.add(rescue);

        JLabel lblpassword = new JLabel("Password");
        lblpassword.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblpassword.setBounds(40, 160, 150, 25);
        lblpassword.setForeground(Color.BLACK);
        p1.add(lblpassword);

        tfpassword = new JTextField();
        tfpassword.setBounds(170, 160, 150, 25);
        tfpassword.setBackground(new Color(255,179,0));
        p1.add(tfpassword);

        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.white);
        back.setBounds(150, 210, 120, 35);
        back.addActionListener(this);
        p1.add(back);


        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == search){
            try{
                String query = "select * from user where username = '"+tfusername.getText()+ "'";
                con c = new con();

                ResultSet rs = c.statement.executeQuery(query);
                while(rs.next()){
                    tfname.setText(rs.getString("Name"));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        else if(ae.getSource()==rescue){
            try{
                String query = "select * from user where username = '"+tfusername.getText()+ "'";
                con c = new con();

                ResultSet rs = c.statement.executeQuery(query);
                while(rs.next()){
                    tfpassword.setText(rs.getString("Password"));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        else{
            setVisible(false);
            new UserLogin();
        }
    }

    public static void main(String[] args){
        new ForgetPass();

    }




}

