package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class User extends JFrame {

    User() {

        JPanel panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBounds(5, 160, 880, 670);
        panel1.setBackground(new Color(109, 164, 170));
        add(panel1);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(5, 5, 855, 150);
        panel.setBackground(new Color(0, 105, 20));
        add(panel);

//        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/GH2.jpg"));
//        Image image = i1.getImage().getScaledInstance(150, 170, Image.SCALE_DEFAULT);
//        ImageIcon i2 = new ImageIcon(image);
//        JLabel label = new JLabel(i2);
//        label.setBounds(910, 0, 250, 150);
//        panel.add(label);

        ImageIcon i10 = new ImageIcon(ClassLoader.getSystemResource("icon/Mainlogo.png"));
        Image image9 = i10.getImage().getScaledInstance(300, 100, Image.SCALE_DEFAULT);
        ImageIcon i20 = new ImageIcon(image9);
        JLabel label1 = new JLabel(i20);
        label1.setBounds(17, 35, 840, 100);
        panel.add(label1);

        JButton btn1 = new JButton("View Appointments");
        btn1.setBounds(180, 80, 200, 30);
        btn1.setBackground(new Color(246, 215, 118));
        panel1.add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AllAppointments();
            }
        });

        JButton btn2 = new JButton("Book Appointment");
        btn2.setBounds(180, 133, 200, 30);
        btn2.setBackground(new Color(246, 215, 118));
        panel1.add(btn2);
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Appointment();
            }
        });

        JButton btn3 = new JButton("Search Room");
        btn3.setBounds(180, 185, 200, 30);
        btn3.setBackground(new Color(246, 215, 118));
        panel1.add(btn3);
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SearchRoom();
            }
        });

        JButton btn4 = new JButton("Update Profile");
        btn4.setBounds(420, 133, 200, 30);
        btn4.setBackground(new Color(246, 215, 118));
        panel1.add(btn4);
        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new update_patient_details();
            }
        });

        JButton btn5 = new JButton("Room");
        btn5.setBounds(420, 80, 200, 30);
        btn5.setBackground(new Color(246, 215, 118));
        panel1.add(btn5);
        btn5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Room();
            }
        });

        JButton btn6 = new JButton("Logout");
        btn6.setBounds(420, 185, 200, 30);
        btn6.setBackground(new Color(246, 215, 118));
        panel1.add(btn6);
        btn6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new UserLogin();
            }
        });

        setTitle("User");
        setSize(880, 500);
        setLocation(500, 250);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new User();
    }
}
