package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Appointment extends JFrame implements ActionListener {
    private con connection;
    private JTextField tfPatientId, tfDoctorId, tfDate, tfReason;
    private JButton btnAddAppointment,btnback;

    public Appointment() {
        setTitle("Appointments Management");


        setSize(500, 350);
        setLocationRelativeTo(null);

        connection = new con();

        JPanel panel = new JPanel();
        panel.setBackground(new Color(109, 164, 170));
        panel.setBounds(5, 160, 300, 300);
        panel.setLayout(null);
        getContentPane().add(panel);


        JLabel lblPatientId = new JLabel("Patient ID:");
        lblPatientId.setBounds(20, 20, 100, 30);
        lblPatientId.setFont(new Font("Tahoma",Font.BOLD,16));
        lblPatientId.setForeground(Color.BLACK);
        panel.add(lblPatientId);

        tfPatientId = new JTextField();
        tfPatientId.setBounds(250, 20, 200, 30);
        tfPatientId.setBackground(new Color(255,179,0));
        panel.add(tfPatientId);

        // Doctor ID
        JLabel lblDoctorId = new JLabel("Doctor ID:");
        lblDoctorId.setBounds(20, 60, 100, 30);
        lblDoctorId.setFont(new Font("Tahoma",Font.BOLD,16));
        lblDoctorId.setForeground(Color.BLACK);

        panel.add(lblDoctorId);

        tfDoctorId = new JTextField();
        tfDoctorId.setBounds(250, 60, 200, 30);
        tfDoctorId.setBackground(new Color(255,179,0));

        panel.add(tfDoctorId);


        JLabel lblDate = new JLabel("Appointment Date:");
        lblDate.setBounds(20, 100, 180, 30);
        lblDate.setFont(new Font("Tahoma",Font.BOLD,16));
        lblDate.setForeground(Color.BLACK);
        panel.add(lblDate);

        tfDate = new JTextField();
        tfDate.setBounds(250, 100, 200, 30);
        tfDate.setBackground(new Color(255,179,0));

        panel.add(tfDate);


        JLabel lblReason = new JLabel("Reason:");
        lblReason.setBounds(20, 140, 200, 30);
        lblReason.setFont(new Font("Tahoma",Font.BOLD,16));
        lblReason.setForeground(Color.BLACK);

        panel.add(lblReason);

        tfReason = new JTextField();
        tfReason.setBounds(250, 140, 200, 30);
        tfReason.setBackground(new Color(255,179,0));
        panel.add(tfReason);


        btnAddAppointment = new JButton("Add Appointment");
        btnAddAppointment.setBounds(80, 230, 180, 30);
        btnAddAppointment.setFont(new Font("Tahoma",Font.BOLD,15));
        btnAddAppointment.setBackground( Color.BLACK);
        btnAddAppointment.setForeground( Color.white);
        btnAddAppointment.addActionListener(this);
        panel.add(btnAddAppointment);

        btnback = new JButton("Back");
        btnback.setBounds(290, 230, 120, 30);
        btnback.setFont(new Font("Tahoma",Font.BOLD,15));
        btnback.setBackground( Color.BLACK);
        btnback.setForeground( Color.white);
        btnback.addActionListener(this);
        panel.add(btnback);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAddAppointment) {
            try {
                int patientId = Integer.parseInt(tfPatientId.getText());
                int doctorId = Integer.parseInt(tfDoctorId.getText());
                String date = tfDate.getText();
                String reason = tfReason.getText();

                // Check if the provided patient ID exists
                ResultSet patientResult = connection.statement.executeQuery("SELECT * FROM patient_info WHERE patient_id = " + patientId);
                if (!patientResult.next()) {
                    JOptionPane.showMessageDialog(this, "patient_info with ID " + patientId + " does not exist.");
                    new Appointment();
                }

                // Check if the provided doctor ID exists
                ResultSet doctorResult = connection.statement.executeQuery("SELECT * FROM EMP_INFO WHERE  Employee_ID = " + doctorId);
                if (!doctorResult.next()) {
                    JOptionPane.showMessageDialog(this, "Doctor with ID " + doctorId + " does not exist.");
                     new Appointment();
                }

                // Insert the appointment
                connection.statement.executeUpdate("INSERT INTO Appointments (patient_id, doctor_id, appointment_date, reason) VALUES ('" + patientId + "', '" + doctorId + "', '" + date + "', '" + reason + "')");
                JOptionPane.showMessageDialog(this, "Appointment added successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input format.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error adding appointment: " + ex.getMessage());
            }
        }

        else if (e.getSource() == btnback) {
            setVisible(false);
        }

    }

    public static void main(String[] args) {
        new Appointment();
    }
}
